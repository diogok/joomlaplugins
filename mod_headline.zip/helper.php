<?
class mod_headlineHelper {
}
?>
