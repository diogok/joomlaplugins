<?php
function com_uninstall() {
	echo "Userlist Successfully Uninstalled<br />
	Visit <a href=\"http://www.sakic.net\" target=\"blank\">www.sakic.net</a> for more exciting Joomla! / Mambo addons.";
}
?>