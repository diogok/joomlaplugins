<?php
function com_install() {
	echo "Userlist Successfully Installed<br />
	Visit <a href=\"http://www.sakic.net\" target=\"blank\">www.sakic.net</a> for more exciting Joomla! / Mambo addons.";
}
?>