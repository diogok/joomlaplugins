<?php

DEFINE ('_USRL_USERLIST','K�ytt�j�t');
DEFINE ('_USRL_REGISTERED_USERS','%s sivustolla on <b>%d</b> rekister�ity� k�ytt�j��');
DEFINE ('_USRL_SEARCH_ALERT','Sy�t� etsitt�v� teksti.');
DEFINE ('_USRL_SEARCH','Etsi k�ytt�j�');
DEFINE ('_USRL_SEARCH_BUTTON','Etsi');
DEFINE ('_USRL_LIST_ALL','N�yt� kaikki');

DEFINE ('_USRL_NAME','Nimi');
DEFINE ('_USRL_USERNAME','K�ytt�j�tunnus');
DEFINE ('_USRL_EMAIL','S�hk�posti');
DEFINE ('_USRL_USERTYPE','Tyyppi');
DEFINE ('_USRL_JOIN_DATE','Liittymisp�iv�');
DEFINE ('_USRL_LAST_LOGIN','Viimeksi kirjautunut');
DEFINE ('_USRL_NEVER','Ei koskaan');

DEFINE ('_USRL_ASC','Nouseva');
DEFINE ('_USRL_DESC','Laskeva');

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y');

?>