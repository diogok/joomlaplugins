<?php

DEFINE ('_USRL_USERLIST','Userlist');
DEFINE ('_USRL_REGISTERED_USERS','%s has <b>%d</b> registered users');
DEFINE ('_USRL_SEARCH_ALERT','Please enter a value to search!');
DEFINE ('_USRL_SEARCH','Find user');
DEFINE ('_USRL_SEARCH_BUTTON','Search');
DEFINE ('_USRL_LIST_ALL','List all');

DEFINE ('_USRL_NAME','Name');
DEFINE ('_USRL_USERNAME','Username');
DEFINE ('_USRL_EMAIL','E-mail');
DEFINE ('_USRL_USERTYPE','Usertype');
DEFINE ('_USRL_JOIN_DATE','Join date');
DEFINE ('_USRL_LAST_LOGIN','Last login');
DEFINE ('_USRL_NEVER','Never');

DEFINE ('_USRL_ASC','Ascending');
DEFINE ('_USRL_DESC','Descending');

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y');

?>