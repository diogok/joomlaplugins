<?php

DEFINE ('_USRL_USERLIST','Lista korisnika');
DEFINE ('_USRL_REGISTERED_USERS','%s ima <b>%d</b> registrovanih �lanova');
DEFINE ('_USRL_SEARCH_ALERT','Molim unesite pojam za pretragu!');
DEFINE ('_USRL_SEARCH','Na�i korisnika');
DEFINE ('_USRL_SEARCH_BUTTON','Tra�i');
DEFINE ('_USRL_LIST_ALL','Izlistaj sve');

DEFINE ('_USRL_NAME','Ime');
DEFINE ('_USRL_USERNAME','Korisni�ko ime');
DEFINE ('_USRL_EMAIL','E-mail');
DEFINE ('_USRL_USERTYPE','Korisni�ki tip');
DEFINE ('_USRL_JOIN_DATE','Datum registracije');
DEFINE ('_USRL_LAST_LOGIN','Zadnji ulazak');
DEFINE ('_USRL_NEVER','Nikad');

DEFINE ('_USRL_ASC','Penju�i');
DEFINE ('_USRL_DESC','Padaju�i');

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y');

?>