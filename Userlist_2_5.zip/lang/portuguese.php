<?php

DEFINE ('_USRL_USERLIST','Lista de Utilizadores');
DEFINE ('_USRL_REGISTERED_USERS','%s tem <b>%d</b> utilizadores registados');
DEFINE ('_USRL_SEARCH_ALERT','Por favor introduza o que pretende pesquisar!');
DEFINE ('_USRL_SEARCH','Pesquisar um utilizador');
DEFINE ('_USRL_SEARCH_BUTTON','Pesquisar');
DEFINE ('_USRL_LIST_ALL','Listar todos');

DEFINE ('_USRL_NAME','Nome');
DEFINE ('_USRL_USERNAME','nome de Utilizador');
DEFINE ('_USRL_EMAIL','E-mail');
DEFINE ('_USRL_USERTYPE','tipo de Utilizador');
DEFINE ('_USRL_JOIN_DATE','Data de ades�o');
DEFINE ('_USRL_LAST_LOGIN','O �ltimo Login');
DEFINE ('_USRL_NEVER','Nunca');

DEFINE ('_USRL_ASC','Crescente');
DEFINE ('_USRL_DESC','Descrescente');

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y');

?>