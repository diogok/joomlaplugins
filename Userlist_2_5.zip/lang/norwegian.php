<?php

DEFINE ('_USRL_USERLIST','Brukerliste');
DEFINE ('_USRL_REGISTERED_USERS','%s har	 <b>%d</b> registrerte brukere');
DEFINE ('_USRL_SEARCH_ALERT','Vennligst skriv inn et s�keord!');
DEFINE ('_USRL_SEARCH','Finn bruker');
DEFINE ('_USRL_SEARCH_BUTTON','S�k');
DEFINE ('_USRL_LIST_ALL','Vis alle');

DEFINE ('_USRL_NAME','Navn');
DEFINE ('_USRL_USERNAME','Brukernavn');
DEFINE ('_USRL_EMAIL','E-post');
DEFINE ('_USRL_USERTYPE','Brukertype');
DEFINE ('_USRL_JOIN_DATE','Registrert');
DEFINE ('_USRL_LAST_LOGIN','Sist sett');
DEFINE ('_USRL_NEVER','Aldri');

DEFINE ('_USRL_ASC','Stigende');
DEFINE ('_USRL_DESC','Synkende');

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y');

?>