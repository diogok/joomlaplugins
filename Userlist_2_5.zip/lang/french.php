<?php

DEFINE ('_USRL_USERLIST','Liste des utilisateurs');
DEFINE ('_USRL_REGISTERED_USERS','%s a <b>%d</b> utilisateurs enregistr�s');
DEFINE ('_USRL_SEARCH_ALERT','Entrez une valeur � rechercher');
DEFINE ('_USRL_SEARCH','Chercher un utilisateur');
DEFINE ('_USRL_SEARCH_BUTTON','Chercher');
DEFINE ('_USRL_LIST_ALL','Toute la liste');

DEFINE ('_USRL_NAME','Nom');
DEFINE ('_USRL_USERNAME','Login');
DEFINE ('_USRL_EMAIL','E-mail');
DEFINE ('_USRL_USERTYPE','Groupe');
DEFINE ('_USRL_JOIN_DATE','Inscrit depuis le');
DEFINE ('_USRL_LAST_LOGIN','Derni�re connexion');
DEFINE ('_USRL_NEVER','Jamais');

DEFINE ('_USRL_ASC','Ascendant');
DEFINE ('_USRL_DESC','Descendant');

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y');

?>