<?php

DEFINE ('_USRL_USERLIST','Lista Utenti');
DEFINE ('_USRL_REGISTERED_USERS','%s ha <b>%d</b> utenti registrati');
DEFINE ('_USRL_SEARCH_ALERT','Inserisci un valore da ricercare!');
DEFINE ('_USRL_SEARCH','Trova utente');
DEFINE ('_USRL_SEARCH_BUTTON','Cerca');
DEFINE ('_USRL_LIST_ALL','Mostra tutti');

DEFINE ('_USRL_NAME','Nome');
DEFINE ('_USRL_USERNAME','Nome utente');
DEFINE ('_USRL_EMAIL','E-mail');
DEFINE ('_USRL_USERTYPE','Tipo utente');
DEFINE ('_USRL_JOIN_DATE','Data di registrazione');
DEFINE ('_USRL_LAST_LOGIN','Ultimo login');
DEFINE ('_USRL_NEVER','Mai');

DEFINE ('_USRL_ASC','Ascendente');
DEFINE ('_USRL_DESC','Discendente');

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y');

?>