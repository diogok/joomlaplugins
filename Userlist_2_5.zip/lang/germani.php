<?php 
// germani translation for sakas userlist
DEFINE ('_USRL_USERLIST','Userliste'); 
DEFINE ('_USRL_REGISTERED_USERS','%s hat <b>%d</b> registrierte User'); 
DEFINE ('_USRL_SEARCH_ALERT','Bitte gib einen Begriff zur Suche ein!'); 
DEFINE ('_USRL_SEARCH','Finde User'); 
DEFINE ('_USRL_SEARCH_BUTTON','Suche'); 
DEFINE ('_USRL_LIST_ALL','Zeige alle'); 

DEFINE ('_USRL_NAME','Name'); 
DEFINE ('_USRL_USERNAME','Username'); 
DEFINE ('_USRL_EMAIL','E-mail'); 
DEFINE ('_USRL_USERTYPE','Usertype'); 
DEFINE ('_USRL_JOIN_DATE','Registrierungsdatum'); 
DEFINE ('_USRL_LAST_LOGIN','Letzter Login'); 
DEFINE ('_USRL_NEVER','Nie'); 

DEFINE ('_USRL_ASC','Aufsteigend'); 
DEFINE ('_USRL_DESC','Absteigend'); 

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y'); 

?>