<?php

DEFINE ('_USRL_USERLIST','Gebruikerslijst');
DEFINE ('_USRL_REGISTERED_USERS','%s heeft <b>%d</b> geregistreerde
gebruikers');
DEFINE ('_USRL_SEARCH_ALERT','Voer s.v.p. een waarde om te zoeken in!');
DEFINE ('_USRL_SEARCH','Vind gebruiker');
DEFINE ('_USRL_SEARCH_BUTTON','Zoek');
DEFINE ('_USRL_LIST_ALL','Geef alles weer');

DEFINE ('_USRL_NAME','Naam');
DEFINE ('_USRL_USERNAME','Gebruikersnaam');
DEFINE ('_USRL_EMAIL','E-mail');
DEFINE ('_USRL_USERTYPE','Soort gebruiker');
DEFINE ('_USRL_JOIN_DATE','Registratie datum');
DEFINE ('_USRL_LAST_LOGIN','Laatste login');
DEFINE ('_USRL_NEVER','Nooit');

DEFINE ('_USRL_ASC','Oplopend');
DEFINE ('_USRL_DESC','Aflopend');

DEFINE ('_USRL_DATE_FORMAT','%d-%m-%Y');

?>