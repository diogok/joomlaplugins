<?php

DEFINE ('_USRL_USERLIST','Anv�ndarlista');
DEFINE ('_USRL_REGISTERED_USERS','%s har <b>%d</b> registrerade anv�ndare');
DEFINE ('_USRL_SEARCH_ALERT','V�nligen ange ett s�k�rd!');
DEFINE ('_USRL_SEARCH','Hitta anv�ndare');
DEFINE ('_USRL_SEARCH_BUTTON','S�k');
DEFINE ('_USRL_LIST_ALL','Lista alla');

DEFINE ('_USRL_NAME','Namn');
DEFINE ('_USRL_USERNAME','Anv�ndarnamn');
DEFINE ('_USRL_EMAIL','E-post');
DEFINE ('_USRL_USERTYPE','Anv�ndartyp');
DEFINE ('_USRL_JOIN_DATE','Registreringsdatum');
DEFINE ('_USRL_LAST_LOGIN','Sista inloggning');
DEFINE ('_USRL_NEVER','Aldrig');

DEFINE ('_USRL_ASC','Stigande');
DEFINE ('_USRL_DESC','Fallande');

DEFINE ('_USRL_DATE_FORMAT','%d.%m.%Y');

?>