<? if(!isset($banners[0])) return ;?>
<? $banner = $banners[0]; ?>
<div align="center" class="frontBanner"><a href="<?=$banner["link"]?>" target="_blank"><img src="<?=$banner["path"]?>" border=0 class="images"></a></div>
<? if(!isset($banners[1])) return ;?>
<? $banner = $banners[1]; ?>
<div align="center" class="frontBanner"><a href="<?=$banner["link"]?>" target="_blank"><img src="<?=$banner["path"]?>" border=0 class="images"></a></div>
