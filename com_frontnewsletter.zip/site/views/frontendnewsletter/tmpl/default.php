<?defined('_JEXEC') or die('Restricted access'); ?>
<h1>Newsletters</h1>
<p><a href="<?=JRoute::_("index.php?option=com_frontnewsletter&view=new")?>">Create new newsletter</a></p>
