<?

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

class frontuploaderViewfrontuploader extends JView {

    function display($tpl = null){
        $model = $this->getModel();
        $this->assignRef("title","File list");
        $this->assignRef("files",$model->getFiles()) ;
        $user = JFactory::getUser();
        if(stripos($user->type,"admin") === false) {
            $this->assignRef("isAdmin",false);
        } else {
            $this->assignRef("isAdmin",true);
        }
        parent::display($tpl);
    }
}
?>
