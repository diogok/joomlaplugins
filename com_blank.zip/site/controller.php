<?
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.controller');
 
class blankController extends JController {

    function display() {
        parent::display();
    }


}
?>
