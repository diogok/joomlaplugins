DROP TABLE IF EXISTS #__simplestforum_forum;
DROP TABLE IF EXISTS #__simplestforum_post;
DROP TABLE IF EXISTS #__simplestforum_extension_attributes;
