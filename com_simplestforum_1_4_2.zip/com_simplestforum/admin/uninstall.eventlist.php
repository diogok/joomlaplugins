<?php
function com_uninstall()
{
?>
<p>
    You have successfully removed the simplest forum component and all of its
    database tables (except back up tables created from within the Simplest
    Forum administration interface).
</p>
<?php
}
?>
