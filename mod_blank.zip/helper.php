<?
class mod_blankHelper {
}
?>
